using System;
using System.Collections.Generic;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook
{
    public class NeuralNetworkFlash
    {
        internal readonly Vector<double>[] SignalsSum;
        internal readonly Vector<double>[] InputSignals;
        public double[] ResultSignals { get; internal set; }
        public NeuralNetworkFlash(int size)
        {
            SignalsSum = new Vector<double>[size];
            InputSignals = new Vector<double>[size + 1];
        }
    }
}
