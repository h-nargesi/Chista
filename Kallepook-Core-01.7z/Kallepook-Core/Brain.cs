using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook
{
    public abstract class Brain
    {
        private const int lock_time_out = 1000;
        private readonly ReaderWriterLock locker = new ReaderWriterLock();

        protected Matrix<double>[] synapses;
        protected Vector<double>[] bias;

        public double LearningFactor { get; set; } = 1;
        public double CertaintyFactor { get; set; } = 0;
        public uint SignalRange { get; private set; } = 1;
        public uint SignalDepth { get; private set; } = 0;
        public double SignalIntensity { get; private set; } = 1;

        protected virtual Vector<double> Standardize(Vector<double> values)
        {
            if (SignalDepth > 0) values += SignalDepth;
            if (SignalRange > 1) values /= SignalRange;
            return values;
        }
        protected virtual Vector<double> Normalize(Vector<double> values)
        {
            if (SignalRange > 1) values *= SignalRange;
            if (SignalDepth > 0) values -= SignalDepth;
            return values;
        }

        protected abstract Matrix<double> Regularize(int leayer);
        protected abstract Vector<double> Conduct(NeuralNetworkFlash flash, int layer);
        protected abstract Vector<double> ConductDerivative(NeuralNetworkFlash flash, int layer);
        protected abstract Vector<double> ErrorCalculation(Vector<double> output, Vector<double> values);

        private void CheckValidation(Matrix<double>[] synapses, Vector<double>[] bias)
        {
            if (synapses == null)
                throw new ArgumentNullException(nameof(synapses),
                    "The brain-image's synapses are undefined.");

            if (bias == null)
                throw new ArgumentNullException(nameof(bias),
                    "The brain-image's biases are undefined.");

            if (synapses.Length < 1)
                throw new ArgumentException(nameof(bias),
                    "The brain-image's synapses layer count is too low.");

            string messages = null;
            if (bias.Length < 1)
                messages +=
                    "\r\nThe brain-image's bias layer count is not mathed with synapses.";

            int? prv_length = null;
            var i = 0;
            while (i < synapses.Length)
            {
                if (synapses[i].RowCount < 1)
                    messages += $"\r\nThe number of neoron of layar {i} is zero.";

                if (i < bias.Length && bias[i].Count != synapses[i].RowCount)
                    messages += $"\r\nThe number of neoron's bias of layar {i} is not correct.";

                if (prv_length != null && prv_length != synapses[i].ColumnCount)
                    messages += $"\r\nThe number of synapses of layar {i} is not match with previous layer's neoron count.";
                prv_length = synapses[i].RowCount;

                i++;
            }

            if (messages != null)
                throw new ArgumentException($"{nameof(synapses)}, {nameof(bias)}", messages);
        }
        public void Initialize(NeuralNetworkImage image)
        {
            CheckValidation(image.synapses, image.bias);

            // it's for multi-thread using
            locker.AcquireWriterLock(lock_time_out);
            try
            {
                SignalRange = image.range;
                SignalDepth = image.depth;

                synapses = new Matrix<double>[image.synapses.Length];
                bias = new Vector<double>[image.bias.Length];
                var i = image.synapses.Length;
                while (--i >= 0)
                {
                    synapses[i] = image.synapses[i].Clone();
                    bias[i] = image.bias[i].Clone();
                }
            }
            finally { locker.ReleaseWriterLock(); }
        }
        public void InitializeRandom(int[] layers_sizes, uint range = 1, uint depth = 0)
        {
            if (layers_sizes == null)
                throw new ArgumentNullException(nameof(layers_sizes),
                    "The layers-sizes is undefined.");
            string error = null;
            for (int ls = 0; ls < layers_sizes.Length; ls++)
                if (layers_sizes[ls] == 0) error += $", {ls}";
            if (error != null)
                throw new ArgumentException(nameof(layers_sizes),
                    $"The layers-sizes is zero in layer(s) {error.Substring(2)}.");

            if (range < 1) throw new ArgumentOutOfRangeException(nameof(range),
                $"The {nameof(range)} must be greater than one.");

            // it's for multi-thread using
            locker.AcquireWriterLock(lock_time_out);
            try
            {
                SignalRange = range;
                SignalDepth = depth;

                synapses = new Matrix<double>[layers_sizes.Length - 1];
                bias = new Vector<double>[layers_sizes.Length - 1];

                int i = -1, max = layers_sizes.Length - 1;
                while (++i < max)
                {
                    synapses[i] = Matrix<double>.Build.Random(
                        layers_sizes[i + 1], layers_sizes[i]);
                    bias[i] = Vector<double>.Build.Random(layers_sizes[i + 1]);
                }

                CheckValidation(synapses, bias);
            }
            finally { locker.ReleaseWriterLock(); }
        }
        public void InitializeZero(int[] layers_sizes, uint range = 1, uint depth = 0)
        {
            if (layers_sizes == null)
                throw new ArgumentNullException(nameof(layers_sizes),
                    "The layers-sizes is undefined.");
            string error = null;
            for (int ls = 0; ls < layers_sizes.Length; ls++)
                if (layers_sizes[ls] == 0) error += $", {ls}";
            if (error != null)
                throw new ArgumentException(nameof(layers_sizes),
                    $"The layers-sizes is zero in layer(s) {error.Substring(2)}.");

            if (range < 1) throw new ArgumentOutOfRangeException(nameof(range),
                $"The {nameof(range)} must be greater than one.");

            // it's for multi-thread using
            locker.AcquireWriterLock(lock_time_out);
            try
            {
                SignalRange = range;
                SignalDepth = depth;

                synapses = new Matrix<double>[layers_sizes.Length - 1];
                bias = new Vector<double>[layers_sizes.Length - 1];

                int i = -1, max = layers_sizes.Length - 1;
                while (++i < max)
                {
                    synapses[i] = Matrix<double>.Build.DenseOfArray(
                        new double[layers_sizes[i + 1], layers_sizes[i]]
                    );
                    bias[i] = Vector<double>.Build.DenseOfArray(
                        new double[layers_sizes[i + 1]]
                    );
                }

                CheckValidation(synapses, bias);
            }
            finally { locker.ReleaseWriterLock(); }
        }
        public NeuralNetworkImage Image()
        {
            var synapses = new Matrix<double>[this.synapses.Length];
            var bias = new Vector<double>[this.bias.Length];

            // it's for multi-thread using
            locker.AcquireReaderLock(lock_time_out);
            // generate image
            try
            {
                for (int i = 0; i < synapses.Length; i++)
                {
                    synapses[i] = this.synapses[i].Clone();
                    bias[i] = this.bias[i].Clone();
                }

                return new NeuralNetworkImage(synapses, bias, SignalRange, SignalDepth);
            }
            // release the lock
            finally { locker.ReleaseReaderLock(); }
        }

        public NeuralNetworkFlash Stimulate(double[] inputs)
        {
            if (inputs == null)
                throw new ArgumentNullException(nameof(inputs));
            // standardized signals
            var signals = Standardize(Vector<double>.Build.DenseOfArray(inputs));
            // prepare neural network flash
            var flash = new NeuralNetworkFlash(synapses.Length);

            // it's for multi-thread using
            locker.AcquireReaderLock(lock_time_out);
            try
            {
                var i = 0;
                for (; i < synapses.Length; i++)
                {
                    // store input for this layer
                    flash.InputSignals[i] = signals;
                    // multiply inputs and weights plus bias
                    flash.SignalsSum[i] = synapses[i].Multiply(signals) + bias[i];
                    // apply sigmoind function on results
                    signals = Conduct(flash, i);
                }
                // store last output
                flash.InputSignals[i] = signals;
                // normalaize result to return
                flash.ResultSignals = Normalize(signals).ToArray();
            }
            finally { locker.ReleaseReaderLock(); }

            return flash;
        }
        public void Reflect(NeuralNetworkFlash flash, double[] values)
        {
            if (flash == null)
                throw new ArgumentNullException(nameof(flash));
            if (values == null)
                throw new ArgumentNullException(nameof(values));

            // standardized signals and calculate error
            var delta = ErrorCalculation(
                flash.InputSignals[^1], Standardize(Vector<double>.Build.DenseOfArray(values)));

            // it's for multi-thread using
            locker.AcquireWriterLock(lock_time_out);
            try
            {
                var i = synapses.Length;
                while (--i >= 0)
                {
                    // calculate next delta
                    delta = delta.PointwiseMultiply(ConductDerivative(flash, i));

                    // find out bias and weights differances
                    var delta_bias = LearningFactor * delta;
                    var delta_weight =
                        Matrix<double>.Build.DenseOfColumnVectors(delta_bias) *
                        Matrix<double>.Build.DenseOfRowVectors(flash.InputSignals[i]);

                    // regularization
                    // if (CertaintyFactor > 0)
                    //    delta_weight -= Regularize(i);

                    // prepare delta for next loop (previous layer)
                    delta = synapses[i].Transpose().Multiply(delta);

                    // apply bias and weights differances
                    bias[i] += delta_bias;
                    synapses[i] += delta_weight;
                }
            }
            finally { locker.ReleaseWriterLock(); }
        }

        private Vector<double> Error(NeuralNetworkFlash flash, double[] values)
        {
            if (flash == null)
                throw new ArgumentNullException(nameof(flash));
            if (values == null)
                throw new ArgumentNullException(nameof(values));

            // calucate errors
            return ErrorCalculation(
                Vector<double>.Build.DenseOfArray(flash.ResultSignals),
                Vector<double>.Build.DenseOfArray(values));
        }
        public double[] Errors(NeuralNetworkFlash flash, double[] values)
        {
            var error = Error(flash, values);

            var result = error.AsArray();
            if (result == null) result = error.ToArray();

            return result;
        }
        public double ErrorTotal(NeuralNetworkFlash flash, double[] values)
        {
            return Error(flash, values).Sum();
        }
        public double ErrorAverage(NeuralNetworkFlash flash, double[] values)
        {
            if (values.Length < 1) return 0;
            else return ErrorTotal(flash, values) / values.Length;
        }
    }
}
