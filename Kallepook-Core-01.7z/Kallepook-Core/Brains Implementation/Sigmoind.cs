using System;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook
{
    public class Sigmoind : Brain
    {
        protected override Matrix<double> Regularize(int leayer)
        {
            return synapses[leayer] * 2 * CertaintyFactor;
        }
        protected override Vector<double> Conduct(NeuralNetworkFlash flash, int layer)
        {
            return 1 / (1 + (flash.SignalsSum[layer] * -1).PointwiseExp());
        }
        protected override Vector<double> ConductDerivative(NeuralNetworkFlash flash, int layer)
        {
            return flash.InputSignals[layer + 1]
                .PointwiseMultiply(1 - flash.InputSignals[layer + 1]);
        }
        protected override Vector<double> ErrorCalculation(Vector<double> output, Vector<double> values)
        {
            // TODO: use wight to loose certainty
            // error equals to: (true_value - network_output)
            return values - output;
        }
    }
}