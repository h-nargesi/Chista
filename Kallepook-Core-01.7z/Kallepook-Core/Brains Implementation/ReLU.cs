using System;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook
{
    public class ReLU : Brain
    {
        public double? MaximumResult { get; set; } = null;
        protected override Vector<double> Normalize(Vector<double> values)
        {
            values = base.Normalize(values);

            if (MaximumResult != null)
                values = values.PointwiseAbsoluteMinimum(MaximumResult.Value);

            return values;
        }

        protected override Matrix<double> Regularize(int leayer)
        {
            return synapses[leayer] * 0;
        }
        protected override Vector<double> Conduct(NeuralNetworkFlash flash, int layer)
        {
            return flash.SignalsSum[layer].PointwiseMaximum(0);
        }
        protected override Vector<double> ConductDerivative(NeuralNetworkFlash flash, int layer)
        {
            return flash.InputSignals[layer + 1].PointwiseSign();
        }
        protected override Vector<double> ErrorCalculation(Vector<double> output, Vector<double> values)
        {
            // error equals to: (true_value - network_output)
            return values - output;
        }
    }
}