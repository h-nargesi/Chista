using System;
using System.Collections.Generic;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook
{
    public class Straight : ReLU
    {
        public double? MinimumResult { get; set; } = null;
        protected override Vector<double> Normalize(Vector<double> values)
        {
            values = base.Normalize(values);

            if (MinimumResult != null)
                values = values.PointwiseMaximum(MinimumResult.Value);

            return values;
        }

        private Dictionary<int, Vector<double>> one_tables =
            new Dictionary<int, Vector<double>>();

        protected override Matrix<double> Regularize(int leayer)
        {
            return synapses[leayer] * 0;
        }
        protected override Vector<double> Conduct(NeuralNetworkFlash flash, int layer)
        {
            return flash.SignalsSum[layer];
        }
        protected override Vector<double> ConductDerivative(NeuralNetworkFlash flash, int layer)
        {
            var count = flash.SignalsSum[layer].Count;
            if (!one_tables.ContainsKey(count))
            {
                var one_table = Vector<double>.Build.SparseOfArray(new double[count]) + 1;
                one_tables.Add(count, one_table);
                return one_table;
            }
            else return one_tables[count];
        }
        protected override Vector<double> ErrorCalculation(Vector<double> output, Vector<double> values)
        {
            // error equals to: (true_value - network_output)
            return values - output;
        }
    }
}