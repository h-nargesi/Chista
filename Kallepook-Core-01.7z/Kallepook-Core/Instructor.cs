using System;
using System.Threading.Tasks;

namespace Photon.NeuralNetwork.Kallepook
{
    public abstract class Instructor : IDisposable
    {
        private bool stoping = false;

        public Brain Brain { get; }
        public int Offset { get; set; }
        public int Count { get; set; }
        public int Epoch { get; set; }
        public int Tries { get; set; }

        public Instructor(Brain brain)
        {
            Brain = brain ??
                throw new ArgumentNullException(nameof(brain));
        }

        protected abstract void OnInitialize();
        protected abstract Task<Record> GetNextData(int offset);
        protected virtual double[] CheckResultValidation(NeuralNetworkFlash flash, Record record)
        {
            if (Brain.ErrorTotal(flash, record.result) == 0) return null;
            else return record.result;
        }
        protected abstract void OnError(Exception ex);

        public Task Start()
        {
            return Task.Run(() =>
            {
                try
                {
                    OnInitialize();
                    var record_geter = GetNextData(Offset % Count);
                    while (Offset / Count <= Epoch)
                    {
                        if (stoping) return;

                        // current record
                        record_geter.Wait();
                        var record = record_geter.Result;

                        // fetch next record
                        record_geter = GetNextData((Offset + 1) % Count);

                        // call event
                        if (NextData != null)
                            if (stoping) return;
                            else NextData.Invoke(record);

                        if (record != null && record.data != null && record.result != null)
                        {
                            var i = 1;
                            do
                            {
                                if (stoping) return;

                                // pridict
                                var predict = Brain.Stimulate(record.data);

                                // check error
                                var correction = CheckResultValidation(predict, record);
                                if (correction == null) break;

                                // learning
                                Brain.Reflect(predict, correction);

                                // call event
                                if (ReflectFinished != null)
                                    if (stoping) return;
                                    else ReflectFinished.Invoke(predict, record);
                            }
                            while (++i < Tries);
                        }

                        // next offset
                        Offset++;
                    }
					Dispose();
                }
                catch (Exception ex) { OnError(ex); }
            });
        }

        public virtual void Dispose()
        {
            stoping = true;
        }

        protected Action<Record> NextData { get; set; }
        protected Action<NeuralNetworkFlash, Record> ReflectFinished { get; set; }

        protected class Record
        {
            public readonly double[] data, result;
            public readonly object extra;

            public Record(double[] data, double[] result)
            {
                this.data = data;
                this.result = result;
            }
            public Record(double[] data, double[] result, object extra)
            {
                this.data = data;
                this.result = result;
                this.extra = extra;
            }
        }

    }
}