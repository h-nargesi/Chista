using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook.Serializer
{
    class NNIS_Simple_RD : NNImageSerializer
    {
        public override void Serialize(FileStream stream, NeuralNetworkImage image)
        {
            byte[] buffer;

            // serialize range
            buffer = BitConverter.GetBytes(image.range); // 4-bytes
            stream.Write(buffer, 0, buffer.Length);

            // serialize depth
            buffer = BitConverter.GetBytes(image.depth); // 4-bytes
            stream.Write(buffer, 0, buffer.Length);

            // serialize leyar count
            buffer = BitConverter.GetBytes(image.synapses.Length + 1); // 4-bytes
            stream.Write(buffer, 0, buffer.Length);

            // serialize leyar's neuron count
            foreach (var synaps in image.synapses)
            {
                buffer = BitConverter.GetBytes(synaps.ColumnCount); // 4-bytes
                stream.Write(buffer, 0, buffer.Length);
            }
            buffer = BitConverter.GetBytes(image.synapses[^1].RowCount); // 4-bytes
            stream.Write(buffer, 0, buffer.Length);

            // serialize leyar's weights
            for (int l = 0; l < image.synapses.Length; l++)
                for (var i = 0; i < image.synapses[l].RowCount; i++)
                {
                    buffer = BitConverter.GetBytes(image.bias[l][i]); // 8-bytes
                    stream.Write(buffer, 0, buffer.Length);
                    for (var j = 0; j < image.synapses[l].ColumnCount; j++)
                    {
                        buffer = BitConverter.GetBytes(image.synapses[l][i, j]); // 8-bytes
                        stream.Write(buffer, 0, buffer.Length);
                    }
                }
        }
        public override NeuralNetworkImage Restore(FileStream stream)
        {
            var buffer = new byte[4];

            stream.Read(buffer, 0, buffer.Length);
            var range = BitConverter.ToUInt32(buffer, 0);

            stream.Read(buffer, 0, buffer.Length);
            var depth = BitConverter.ToUInt32(buffer, 0);

            stream.Read(buffer, 0, buffer.Length);
            var layer_size = new int[BitConverter.ToInt32(buffer, 0)];

            int i;
            for (i = 0; i < layer_size.Length; i++)
            {
                stream.Read(buffer, 0, buffer.Length);
                layer_size[i] = BitConverter.ToInt32(buffer, 0);
            }

            var matrices = new Matrix<double>[layer_size.Length - 1];
            var vactores = new Vector<double>[matrices.Length];
            buffer = new byte[8];
            for (var l = 0; l < matrices.Length; l++)
            {
                var synapses = new double[layer_size[l + 1], layer_size[l]];
                var bias = new double[layer_size[l + 1]];

                for (i = 0; i < bias.Length; i++)
                {
                    stream.Read(buffer, 0, buffer.Length);
                    bias[i] = BitConverter.ToDouble(buffer, 0);
                    for (var j = 0; j < synapses.GetLength(1); j++)
                    {
                        stream.Read(buffer, 0, buffer.Length);
                        synapses[i, j] = BitConverter.ToDouble(buffer, 0);
                    }
                }

                matrices[l] = Matrix<double>.Build.DenseOfArray(synapses);
                vactores[l] = Vector<double>.Build.DenseOfArray(bias);
            }

            return new NeuralNetworkImage(matrices, vactores, range, depth);
        }
    }
}
