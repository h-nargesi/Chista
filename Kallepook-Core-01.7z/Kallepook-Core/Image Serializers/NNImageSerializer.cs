using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using MathNet.Numerics.LinearAlgebra;

namespace Photon.NeuralNetwork.Kallepook.Serializer
{
    abstract class NNImageSerializer
    {
        public abstract void Serialize(FileStream stream, NeuralNetworkImage image);
        public abstract NeuralNetworkImage Restore(FileStream stream);
        public static ushort GetDefaultVersion(ushort? version)
        {
            return version ?? 1;
        }
        public static NNImageSerializer GetSerializerInstance(ushort version)
        {
            switch (version)
            {
                case 1: return new NNIS_Simple_RD();
                default: throw new Exception($"Invalid serializer version ({version}).");
            }
        }
    }
}
