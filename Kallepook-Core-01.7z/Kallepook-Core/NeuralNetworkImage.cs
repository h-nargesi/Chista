using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using MathNet.Numerics.LinearAlgebra;
using Photon.NeuralNetwork.Kallepook.Serializer;

namespace Photon.NeuralNetwork.Kallepook
{
    public class NeuralNetworkImage
    {
        public readonly uint range, depth;
        public readonly Matrix<double>[] synapses;
        public readonly Vector<double>[] bias;

        public NeuralNetworkImage(
            Matrix<double>[] synapses, Vector<double>[] bias, uint range, uint depth)
        {
            if (synapses == null || synapses.Length == 0)
                throw new ArgumentNullException(nameof(synapses));
            else this.synapses = new Matrix<double>[synapses.Length];

            if (bias == null) throw new ArgumentNullException(nameof(bias));
            else this.bias = new Vector<double>[bias.Length];

            if (synapses.Length != bias.Length)
                throw new ArgumentOutOfRangeException(
                    $"{nameof(synapses)}, {nameof(bias)}",
                    "The synapses and bias are not matched.");

            if (range < 1) throw new ArgumentOutOfRangeException(nameof(range),
                $"The {nameof(range)} must be greater than one.");
            this.range = range;
            this.depth = depth;

            string value = null;
            for (int i = 0; i < synapses.Length; i++)
                if (synapses[i].RowCount != bias[i].Count)
                    value += ", " + i;

            this.synapses = synapses;
            this.bias = bias;

            if (value != null)
                throw new ArgumentException(
                    $"{nameof(synapses)}, {nameof(bias)}",
                    $"The synapses and bias are not matched in layers ({value}).");
        }

        public void Serialize(string path, ushort? version = null)
        {
            version = NNImageSerializer.GetDefaultVersion(version);
            var serializer = NNImageSerializer.GetSerializerInstance(version.Value);

            using var stream = File.Create(path);
            stream.Flush();

            // serialize version
            var buffer = BitConverter.GetBytes(version.Value); // 2-bytes
            stream.Write(buffer, 0, buffer.Length);

            serializer.Serialize(stream, this);
        }
        public static NeuralNetworkImage Restore(string path)
        {
            using var stream = File.OpenRead(path);

            // read version: 2-bytes
            var buffer = new byte[2];
            stream.Read(buffer, 0, buffer.Length);
            var version = BitConverter.ToUInt16(buffer, 0);

            return NNImageSerializer
                .GetSerializerInstance(version)
                .Restore(stream);
        }
    }
}
