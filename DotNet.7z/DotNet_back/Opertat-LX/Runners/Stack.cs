using System;
using System.Text;
using System.Data.SQLite;
using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using Newtonsoft.Json.Linq;

namespace Photon.NeuralNetwork.Opertat.Debug
{
    public class Stack : NeuralNetworkRunner, IDisposable
    {
        public const string NAME = "stk";
        private const int SIGNAL_COUNT = 210;
        private const int RESULT_COUNT = 50;
        private const int RECORD_COUNT = RESULT_COUNT + SIGNAL_COUNT;
        private readonly int company_id = 1;
        private SQLiteCommand sqlite;
        private readonly static string sql_selection = $@"
select CompanyID, round(100 * (Close - LastClose) / LastClose, 2) as Change
from (
	select StackID, CompanyID, Close,
		   lag(Close, 1, Close) over(partition by CompanyID order by StackID) as LastClose
	from stack
    where companyid = &companyid
)
order by StackID
limit {RECORD_COUNT} offset ";

        private string print = "";
        public override string Name => NAME;

        protected override void OnInitialize()
        {
            base.OnInitialize();

            sqlite = new SQLiteCommand(
                new SQLiteConnection(GetSetting(Setting.data_provider, "Data Source=data.sqlite")));
            sqlite.Connection.Open();

            sqlite.CommandText =
                $"select max(count(*) - {RECORD_COUNT}, 0) from stack where companyid = " + company_id;
            using var reader = sqlite.ExecuteReader();
            if (reader.Read()) Count = (int)(long)reader[0];
            else throw new Exception("The unkown count.");
        }
        protected override NeuralNetworkImage BrainInitializer()
        {
            var relu = new SoftReLU();
            var init = new NeuralNetworkInitializer()
                .SetInputSize(SIGNAL_COUNT);

            for (int i = 0; i < 5; i++)
                init.AddLayer(relu, 50 - i);

            init.AddLayer(new Sigmoind(), RESULT_COUNT)
                .SetCorrection(new ErrorStack(RESULT_COUNT),
                    new DataRange(5, 0), new DataRange(10, 5));

            return init.Image();
        }
        protected override async Task<Record> GetNextData(int offset)
        {
            var result = new List<double>(RESULT_COUNT);
            var signal = new List<double>(SIGNAL_COUNT);

            sqlite.CommandText = sql_selection.Replace("&companyid", company_id.ToString()) + offset;
            using var reader = await sqlite.ExecuteReaderAsync();
            while (reader.Read())
            {
                if (signal.Count < SIGNAL_COUNT)
                    signal.Add((double)reader[1]);
                else result.Add((double)reader[1]);
            }

            return new Record(signal.ToArray(), result.ToArray());
        }

        public Stack()
        {
            ReflectFinished = (flash, record) =>
            {
                print = new string(' ', print.Length);
                Debugger.Console.WriteWord(print);
                print = $"#{Offset}: {Brain.ErrorTotal(flash, record.result):R}";
                var er = Brain.ErrorTotal(flash, record.result);
                Debugger.Console.WriteWord(print);
            };
        }

        public override void Dispose()
        {
            base.Dispose();

            if (sqlite != null)
            {
                var connection = sqlite.Connection;
                sqlite.Dispose();
                connection?.Dispose();
                sqlite = null;
            }
        }
    }
}