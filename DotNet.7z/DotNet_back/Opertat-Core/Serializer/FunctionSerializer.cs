using System;
using System.Collections.Generic;
using System.IO;

namespace Photon.NeuralNetwork.Opertat.Implement
{
    class FunctionSerializer
    {
        FileStream stream;
        public FunctionSerializer(FileStream stream)
        {
            this.stream = stream ??
                throw new ArgumentNullException(nameof(stream), "The writer stream is not defined");
        }

        public void Serialize(IErrorFunction error_func)
        {
            ushort code;
            List<byte> parameters;
            switch (error_func)
            {
                case Errorest e:
                    code = 1;
                    parameters = null;
                    break;

                case ErrorStack e:
                    code = 2;
                    parameters = new List<byte>();
                    parameters.AddRange(BitConverter.GetBytes(e.IndexCount));
                    break;

                default:
                    throw new ArgumentException(
                        nameof(error_func), "this type of IErrorFunction is not registered.");
            }

            // serialaize type and parameters
            Serialize(code, parameters?.ToArray());
        }
        public void Serialize(IDataConvertor convertor)
        {
            ushort code;
            List<byte> parameters;
            if (convertor == null)
            {
                code = 0;
                parameters = null;
            }
            else switch (convertor)
                {
                    case DataRange data_range:
                        code = 1;
                        parameters = new List<byte>();
                        parameters.AddRange(BitConverter.GetBytes(data_range.SignalRange));
                        parameters.AddRange(BitConverter.GetBytes(data_range.SignalHeight));
                        break;
                    default:
                        throw new ArgumentException(
                            nameof(convertor), "this type of IDataConvertor is not registered.");
                }

            // serialaize type and parameters
            Serialize(code, parameters?.ToArray());
        }
        private void Serialize(ushort code, byte[] parameters)
        {
            // serialaize type
            var buffer = BitConverter.GetBytes(code); // 2-bytes
            stream.Write(buffer, 0, buffer.Length);

            // without parameters
            if (parameters == null || parameters.Length == 0) return;

            // serialaize parameters
            stream.Write(parameters, 0, parameters.Length);
        }

        public IErrorFunction RestorIErrorFunction()
        {
            byte[] buffer;
            var code = RestorFunctionType();

            switch (code)
            {
                case 1: return new Errorest();
                case 2:
                    buffer = RestorParameter(4);
                    return new ErrorStack(BitConverter.ToInt32(buffer, 0));
                default:
                    throw new Exception(
                        $"this type of IErrorFunction ({code}) is not registered.");
            }
        }
        public IDataConvertor RestorIDataConvertor()
        {
            byte[] buffer;
            var code = RestorFunctionType();

            switch (code)
            {
                case 0: return null;
                case 1:
                    buffer = RestorParameter(8);
                    return new DataRange(
                        BitConverter.ToUInt32(buffer, 0),
                        BitConverter.ToInt32(buffer, 4));
                default:
                    throw new Exception(
                        $"This type of IDataConvertor ({code}) is not registered.");
            }
        }
        private ushort RestorFunctionType()
        {
            var buffer = new byte[2];
            stream.Read(buffer, 0, buffer.Length);
            return BitConverter.ToUInt16(buffer, 0);
        }
        private byte[] RestorParameter(int length)
        {
            var buffer = new byte[length];
            stream.Read(buffer, 0, buffer.Length);
            return buffer;
        }

        public static ushort EnCodeIConduction(IConduction conduction)
        {
            switch (conduction)
            {
                case Sigmoind sigmoind: return 1;
                case ReLU relu: return 2;
                case SoftReLU soft_relu: return 3;

                default:
                    throw new ArgumentException(
                        nameof(conduction), "this type of IConduction is not registered.");
            }
        }
        private static Dictionary<ushort, IConduction> all_conductions =
            new Dictionary<ushort, IConduction>();
        public static IConduction DecodeIConduction(ushort value)
        {
            if (all_conductions.ContainsKey(value))
                return all_conductions[value];

            IConduction conduction;
            switch (value)
            {
                case 1: conduction = new Sigmoind(); break;
                case 2: conduction = new ReLU(); break;
                case 3: conduction = new SoftReLU(); break;

                default:
                    throw new ArgumentException(
                        nameof(value), "this type of IConduction is not registered.");
            }

            all_conductions.Add(value, conduction);
            return conduction;
        }

    }
}