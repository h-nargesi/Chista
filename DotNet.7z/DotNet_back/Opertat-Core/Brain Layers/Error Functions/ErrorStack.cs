using System;
using MathNet.Numerics.LinearAlgebra;
using Photon.NeuralNetwork.Opertat.Implement;

namespace Photon.NeuralNetwork.Opertat
{
    public class ErrorStack : IErrorFunction
    {
        Vector<double> indexed;

        public ErrorStack(int output_count)
        {
            var ix = new double[output_count];
            for (int i = 0; i < output_count;)
                ix[i] = ++i;

            indexed = Vector<double>.Build.DenseOfArray(ix);
        }

        public int IndexCount { get { return indexed.Count; } }

        public Vector<double> ErrorCalculation(Vector<double> output, Vector<double> values)
        {
            return indexed.PointwiseMultiply(values - output);
        }
    }
}